/*
 * stoplight.c
 *
 * 31-1-2003 : GWA : Stub functions created for CS161 Asst1.
 *
 * NB: You can use any synchronization primitives available to solve
 * the stoplight problem in this file.
 */


/*
 * 
 * Includes
 *
 */

#include <types.h>
#include <lib.h>
#include <test.h>
#include <thread.h>
#include <curthread.h>
#include <synch.h>
#include <queue.h>

/*
 *
 * Constants
 *
 */

/*
 * Number of vehicles created.
 */

#define NVEHICLES 20


/*
 *
 * Function Definitions
 *
 */
enum {routeA, routeB, routeC}; // indices for the directions array below
static const char *msgs[] = {
        "Approaching: ",
        "Entering region: ",
        "Leaving: "
};
enum {APPROACH, REG, LEAVE};
enum {LEFT, RIGHT};
static const char *directions[] = { "routeA", "routeB", "routeC"};
static const char *dirtype[] = { "car", "truck"};
static const char *destype[] = {"RIGHT", "LEFT", "RIGHT"};
struct lock *AB, *BC, *CA, *vehicle_count;
struct lock *leave_right, *leave_left;
struct queue *right, *left;
struct lock *q_r, *q_l;

int vehicles_finished;

static void
kernel_msg(int msg, int vehiclenumber, int vehicledirection, int destdirection, int vehicletype)
{
        kprintf("%s vehicle number = %2d, direction = %s, destination = %s\n, type = %s\n",
                msgs[msg], vehiclenumber, directions[vehicledirection], destype[destdirection],
		dirtype[vehicletype]);
}

/*
 * turnleft()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the vehicle
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the vehicle id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a left turn through the 
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnleft(unsigned long vehicledirection,
		unsigned long vehiclenumber,
		unsigned long vehicletype)
{
	lock_acquire(vehicle_count);
	if(vehicledirection == routeA)
	{
		lock_acquire(BC);
		lock_acquire(AB);
		kernel_msg(REG, vehiclenumber, vehicledirection, RIGHT, vehicletype);
		lock_release(BC);
		lock_release(leave_right);
		lock_release(AB);
		kernel_msg(LEAVE, vehiclenumber, vehicledirection, RIGHT, vehicletype);
	}
	if(vehicledirection == routeB)
	{
		lock_acquire(BC);
		lock_acquire(CA);
		kernel_msg(REG, vehiclenumber, vehicledirection, LEFT, vehicletype);
		lock_release(BC);
		lock_release(leave_left);
		lock_release(CA);
		kernel_msg(LEAVE, vehiclenumber, vehicledirection, LEFT, vehicletype);
	}
	if(vehicledirection == routeC)
        {
                lock_acquire(CA);
                lock_acquire(AB);
                kernel_msg(REG, vehiclenumber, vehicledirection, RIGHT, vehicletype);
                lock_release(CA);
		lock_release(leave_right);
		lock_release(AB);
 		kernel_msg(LEAVE, vehiclenumber, vehicledirection, RIGHT, vehicletype);
       }
	thread_yield();
	lock_release(vehicle_count);
}

/*
 * turnright()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the vehicle
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the vehicle id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a right turn through the 
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnright(unsigned long vehicledirection,
		unsigned long vehiclenumber,
		unsigned long vehicletype)
{
	lock_acquire(vehicle_count);
	if(vehicledirection == routeA)
	{
		lock_acquire(AB);
		kernel_msg(REG, vehiclenumber, vehicledirection, RIGHT, vehicletype);
		lock_release(AB);
		kernel_msg(LEAVE, vehiclenumber, vehicledirection, RIGHT, vehicletype);
		lock_release(leave_right);
	}
	if(vehicledirection == routeB)
	{
		lock_acquire(BC);
		kernel_msg(REG, vehiclenumber, vehicledirection, LEFT, vehicletype);
		lock_release(BC);
		kernel_msg(LEAVE, vehiclenumber, vehicledirection, LEFT, vehicletype);
		lock_release(leave_left);
	}
	if(vehicledirection == routeC)
        {
                lock_acquire(CA);
                kernel_msg(REG, vehiclenumber, vehicledirection, RIGHT, vehicletype);
		lock_acquire(CA);
		kernel_msg(LEAVE, vehiclenumber, vehicledirection, RIGHT, vehicletype);
		lock_release(leave_right);
	}
	thread_yield();
	lock_release(vehicle_count);
}


void which_dir(int turndirection, unsigned long vehicledirection, unsigned long vehiclenumber, unsigned long vehicletype)
{
	switch(turndirection)
	{
	case LEFT: turnleft(vehicledirection, vehiclenumber, vehicletype); break;
	case RIGHT: turnright(vehicledirection, vehiclenumber, vehicletype); break;
	}
}

int destdir(int turndirection, unsigned long vehicledirection)
{
	if(vehicledirection == routeA)
	{
		switch(turndirection)
		{
		case LEFT: return routeC;
		case RIGHT: return routeB;
		}
	}
	if(vehicledirection == routeB)
	{
		switch(turndirection)
		{
		case LEFT: return routeC;
		case RIGHT: return routeB;
		}
	}
	if(vehicledirection == routeC)
        {       
                switch(turndirection)
                {
                case LEFT: return routeC;
                case RIGHT: return routeA;
                }
        }
	return 0;
}

/*
 * approachintersection()
 *
 * Arguments: 
 *      void * unusedpointer: currently unused.
 *      unsigned long vehiclenumber: holds vehicle id number.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      Change this function as necessary to implement your solution. These
 *      threads are created by createvehicles().  Each one must choose a direction
 *      randomly, approach the intersection, choose a turn randomly, and then
 *      complete that turn.  The code to choose a direction randomly is
 *      provided, the rest is left to you to implement.  Making a turn
 *      or going straight should be done by calling one of the functions
 *      above.
 */

static
void
approachintersection(void * unusedpointer,
		unsigned long vehiclenumber)
{
	int vehicledirection, turndirection, vehicletype;
	/*
	 * vehicledirection is set randomly.
	 */
	vehicletype = random() % 2;
	vehicledirection = random() % 3;
	turndirection = random() % 2;
	(void) unusedpointer;
	struct lock *leave = NULL;	

	if(vehicledirection == routeA)
	{	
		lock_acquire(q_r);
		q_addtail(right, curthread);
		kernel_msg(APPROACH, vehiclenumber, vehicledirection, destdir(turndirection, vehicledirection), vehicletype);
		lock_release(q_r);
		leave = leave_right;
	}
	if(vehicledirection == routeB)
	{
		lock_acquire(q_l);
		q_addtail(left, curthread);
	        kernel_msg(APPROACH, vehiclenumber, vehicledirection, destdir(turndirection, vehicledirection), vehicletype);
	        lock_release(q_l);
		leave = leave_left;
	}
	if(vehicledirection == routeC)
        {
                lock_acquire(q_r);
                q_addtail(right, curthread);
                kernel_msg(APPROACH, vehiclenumber, vehicledirection, destdir(turndirection, vehicledirection), vehicletype);
                leave = leave_right;
		lock_release(q_r);
        }
	thread_yield();
	which_dir(turndirection, vehicledirection, vehiclenumber, vehicletype);
	vehicles_finished++;
}

/*
 * createvehicles()
 *
 * Arguments:
 *      int nargs: unused.
 *      char ** args: unused.
 *
 * Returns:
 *      0 on success.
 *
 * Notes:
 *      Driver code to start up the approachintersection() threads.  You are
 *      free to modiy this code as necessary for your solution.
 */

int
createvehicles(int nargs,
		char ** args)
{
	int index, error;
	struct thread *t_vehicle;
	/*
	 * Avoid unused variable warnings.
	 */

	(void) nargs;
	(void) args;

	assert((AB = lock_create("AB")) != NULL);
        assert((BC = lock_create("BC")) != NULL);
        assert((CA = lock_create("CA")) != NULL);
	assert((vehicle_count = lock_create("vehicle_count")) != NULL);	
        assert((q_r = lock_create("q_r")) != NULL);
        assert((q_l = lock_create("q_l")) != NULL);
	assert((leave_right = lock_create("leave_right")) != NULL);
	assert((leave_left = lock_create("leave_left")) != NULL);
        assert((right = q_create(10)) != NULL);
        assert((left = q_create(10)) != NULL);

	/*
	 * Start NVEHICLES approachintersection() threads.
	 */
	for (index = 0; index < NVEHICLES; index++) {

		error = thread_fork("approachintersection thread",
				NULL,
				index,
				approachintersection,
				NULL
				);

		/*
		 * panic() on error.
		 */

		if (error) {

			panic("approachintersection: thread_fork failed: %s\n",
					strerror(error)
				 );
		}
	}
	while(vehicles_finished < NVEHICLES)
        {
		thread_yield();
		int spl = splhigh();
		lock_acquire(q_r);
        	if(!q_empty(right))
        	{
        	     t_vehicle = q_remhead(right);
        	     lock_release(q_r);
		     lock_acquire(leave_right);
		}
        	lock_acquire(q_l);
        	if(!q_empty(left))
        	{
        	     t_vehicle = q_remhead(left);
        	     lock_release(q_l);
		     lock_acquire(leave_left);
		}
		lock_release(q_r);
		lock_release(q_l);
		thread_yield();
		splx(spl);
	}
        lock_destroy(AB);
        lock_destroy(BC);
        lock_destroy(CA);
        lock_destroy(vehicle_count);
        lock_destroy(q_r);
        lock_destroy(q_l);
	lock_destroy(leave_right);
	lock_destroy(leave_left);
        q_destroy(right);
        q_destroy(left);
	return 0;
}
