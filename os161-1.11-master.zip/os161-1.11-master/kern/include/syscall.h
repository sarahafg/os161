#ifndef _SYSCALL_H_
#define _SYSCALL_H_

/*
 * Prototypes for IN-KERNEL entry points for system call implementations.
 */

pid_t sys_fork(struct trapframe* tf);
int sys_reboot(int code);
int sys_getpid(int* ret);
int sys_execv(const char *prog, char **argv);
int sys__exit(int code);
int sys_getppid(int* ret);
int sys_waitpid(pid_t pid, userptr_t status, int options, int *ret);

#endif /* _SYSCALL_H_ */
